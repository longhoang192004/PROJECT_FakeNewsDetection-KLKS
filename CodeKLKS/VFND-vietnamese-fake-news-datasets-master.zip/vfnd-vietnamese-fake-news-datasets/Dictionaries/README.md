# Từ điển

Xây dựng dựa trên các bộ từ điển:
1. 2 file  [tri_grams.txt](https://github.com/deepai-solutions/core_nlp/blob/master/tokenization/tri_grams.txt) và [bi_grams.txt](https://raw.githubusercontent.com/deepai-solutions/core_nlp/master/tokenization/bi_grams.txt) trong [core_nlp]( https://github.com/deepai-solutions/core_nlp)
2. Các file index trong bộ [từ điển Tiếng Việt](http://www.informatik.uni-leipzig.de/~duc/Dict/)